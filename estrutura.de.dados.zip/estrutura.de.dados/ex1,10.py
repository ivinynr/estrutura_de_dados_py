#Crie um programa que simule o jogo "Pedra, Papel e Tesoura" entre o usuário e o computador. O
#programa deve solicitar a escolha do usuário e, em seguida, escolher aleatoriamente a escolha do
#computador e determinar o vencedor.

import random

print("Escolha uma opção:")
print("1 - Pedra")
print("2 - Papel")
print("3 - Tesoura")

escolha_professor = int(input("Insira um número: "))


if escolha_professor < 1 or escolha_professor > 3:
    print("Escolha inválida. Por favor, insira um número entre 1 e 3.")
else:
    escolhas = ["Pedra", "Papel", "Tesoura"]
    escolha_computador = random.randint(1, 3)

    print("Você escolheu:", escolhas[escolha_professor - 1])
    print("O computador escolheu:", escolhas[escolha_computador - 1])


    if escolha_professor == escolha_computador:
        print("Empate!")
    elif (escolha_professor == 1 and escolha_computador == 3) or \
         (escolha_professor == 2 and escolha_computador == 1) or \
         (escolha_professor == 3 and escolha_computador == 2):
        print("Você venceu!")
    else:
        print("O computador venceu!")






