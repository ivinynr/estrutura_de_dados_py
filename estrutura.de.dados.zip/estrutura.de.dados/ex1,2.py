#Crie um programa que determine se um número inserido pelo usuário é par ou ímpar.

numero=int(input("digite um numero: "))

if numero %2==0:
    print('numero{numero} par')
else:
    print('numero{numero} impar')    