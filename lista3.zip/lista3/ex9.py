def adicao(x, y):
    return x + y

def subtracao(x, y):
    return x - y

def multiplicacao(x, y):
    return x * y

def divisao(x, y):
    if y != 0:
        return x / y
    else:
        return "Divisão por zero não é permitida."

print("Escolha a operação:")
print("1. Adição")
print("2. Subtração")
print("3. Multiplicação")
print("4. Divisão")

opcao = int(input("Digite o número da operação desejada: "))

if opcao in [1, 2, 3, 4]:
    numero1 = float(input("Digite o primeiro número: "))
    numero2 = float(input("Digite o segundo número: "))

    if opcao == 1:
        resultado = adicao(numero1, numero2)
    elif opcao == 2:
        resultado = subtracao(numero1, numero2)
    elif opcao == 3:
        resultado = multiplicacao(numero1, numero2)
    else:
        resultado = divisao(numero1, numero2)

    print("Resultado: ", resultado)

else:
    print("Opção inválida. Por favor, escolha uma opção de 1 a 4.")
