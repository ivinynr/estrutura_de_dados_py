def contar_vogais(string):
    vogais = "aeiou"
    quantidade_vogais = 0
    for char in string:
        if char.lower() in vogais:
            quantidade_vogais += 1
    return quantidade_vogais

texto = input("Digite uma palavra para contar as vogais: ")
quantidade_vogais = contar_vogais(texto)
print(f"A quantidade de vogais na palavra é: {quantidade_vogais}")
