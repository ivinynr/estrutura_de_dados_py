def sequencia_fibonacci(n):
    fibonacci = [0, 1]
    while len(fibonacci) < n:
        proximo_numero = fibonacci[-1] + fibonacci[-2]
        fibonacci.append(proximo_numero)
    return fibonacci

numero_de_termos = int(input("Digite o número de termos da sequência de Fibonacci: "))

if numero_de_termos <= 0:
    print("insira um número positivo.")
else:
    resultado = sequencia_fibonacci(numero_de_termos)
    print("Sequência de Fibonacci:")
    print(resultado)
