import re

def palindromo(texto):
    texto = re.sub(r'[^\w]', '', texto).lower()
    return texto == texto[::-1]

palavra_frase = input("Digite uma palavra ou frase para verificar se é um palíndromo: ")

if palindromo(palavra_frase):
    print("É um palíndromo!")
else:
    print("Não é um palíndromo.")
