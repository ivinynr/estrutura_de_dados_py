def terceiro_maior(vetor):
    vetor_unico = list(set(vetor))  
    if len(vetor_unico) < 3:
        return "O vetor não tem pelo menos três números únicos."
    vetor_unico.sort(reverse=True)  
    return vetor_unico[2]  

vetor = [10, 5, 3, 7, 3, 8, 2, 5]

terceiro_maior_numero = terceiro_maior(vetor)
print("O terceiro maior número no vetor é:", terceiro_maior_numero)
