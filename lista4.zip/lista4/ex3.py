def encontrar_maximo(vetor):
    if len(vetor) == 0:
        return "O vetor está vazio."
    maximo = vetor[0]
    for num in vetor:
        if num > maximo:
            maximo = num
    return maximo

def encontrar_minimo(vetor):
    if len(vetor) == 0:
        return "O vetor está vazio."
    minimo = vetor[0]
    for num in vetor:
        if num < minimo:
            minimo = num
    return minimo

vetor = [64, 34, 25, 12, 22, 11, 90]

maximo = encontrar_maximo(vetor)
minimo = encontrar_minimo(vetor)

print("Elemento máximo no vetor:", maximo)
print("Elemento mínimo no vetor:", minimo)
