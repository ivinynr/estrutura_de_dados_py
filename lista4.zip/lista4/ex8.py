def calcular_mediana(vetor):
    vetor_ordenado = sorted(vetor)
    tamanho = len(vetor_ordenado)
    indice_do_meio = tamanho // 2
    
    if tamanho % 2 != 0:
        
        mediana = vetor_ordenado[indice_do_meio]
    else:
        
        mediana = (vetor_ordenado[indice_do_meio - 1] + vetor_ordenado[indice_do_meio]) / 2
    
    return mediana

vetor_impar = [10, 5, 3, 7, 8]
mediana_impar = calcular_mediana(vetor_impar)
print("Mediana do vetor ímpar:", mediana_impar)

vetor_par = [10, 5, 3, 7, 8, 2]
mediana_par = calcular_mediana(vetor_par)
print("Mediana do vetor par:", mediana_par)
