def ordenar_por_selecao(vetor):
    tamanho = len(vetor)
    for i in range(tamanho):
        indice_menor = i
        for j in range(i + 1, tamanho):
            if vetor[j] < vetor[indice_menor]:
                indice_menor = j
        vetor[i], vetor[indice_menor] = vetor[indice_menor], vetor[i]
    return vetor

vetor = [64, 34, 25, 12, 22, 11, 90]
vetor_ordenado = ordenar_por_selecao(vetor)
print("Vetor ordenado:", vetor_ordenado)
