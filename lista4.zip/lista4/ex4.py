def menor(vetor):
    vetor_unico = list(set(vetor))  
    vetor_unico.sort()  
    if len(vetor_unico) >= 2:
        return vetor_unico[1]  
    else:
        return "Não há segundo menor número no vetor."


vetor = [10, 5, 3, 7, 3, 8, 2, 5]

segundo_menor_numero = menor(vetor)
print("O segundo menor número é:", segundo_menor_numero)
