def ordenar_vetor(vetor, ordem='crescente'):
    if ordem == 'crescente':
        return sorted(vetor)
    elif ordem == 'decrescente':
        return sorted(vetor, reverse=True)
    else:
        return "Opção de ordem inválida. Use 'crescente' ou 'decrescente'."

vetor = [64, 34, 25, 12, 22, 11, 90]

ordem_crescente = ordenar_vetor(vetor, 'crescente')
ordem_decrescente = ordenar_vetor(vetor, 'decrescente')

print("Vetor ordenado crescente:", ordem_crescente)
print("Vetor ordenado decrescente:", ordem_decrescente)
