def contar_pares_impares(vetor):
    vetor_ordenado = sorted(vetor, reverse=True)  
    numeros_pares = 0
    numeros_impares = 0
    
    for num in vetor_ordenado:
        if num % 2 == 0:
            numeros_pares += 1
        else:
            numeros_impares += 1
    
    return vetor_ordenado, numeros_pares, numeros_impares

vetor = [5, 2, 9, 10, 15, 3, 7, 8]

vetor_ordenado, pares, impares = contar_pares_impares(vetor)
print("Vetor ordenado em ordem decrescente:", vetor_ordenado)
print("Quantidade de números pares:", pares)
print("Quantidade de números ímpares:", impares)
