def remover_duplicatas(vetor):
    vetor_sem_duplicatas = list(set(vetor))
    return vetor_sem_duplicatas

vetor = [1, 2, 2, 3, 4, 4, 5, 6, 6]

vetor_sem_duplicatas = remover_duplicatas(vetor)
print("Vetor sem elementos duplicados:", vetor_sem_duplicatas)
