class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade
    
    def falar(self):
        print(f"meu nome é {self.nome}.")

 
nome_pessoa = input("Digite o nome da pessoa: ")
idade_pessoa = int(input("Digite a idade da pessoa: "))

pessoa = Pessoa(nome_pessoa, idade_pessoa)
pessoa.falar()
