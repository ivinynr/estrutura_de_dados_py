class Produto:
    def __init__(self, nome, preco, quantidade):
        self.nome = nome
        self.preco = preco
        self.quantidade = quantidade
    
    def calcular_total(self):
        total = self.preco * self.quantidade
        return total
nome_produto = input("Digite o nome do produto: ")
preco_produto = float(input("Digite o preço do produto: "))
quantidade_produto = int(input("Digite a quantidade do produto: "))

produto = Produto(nome_produto, preco_produto, quantidade_produto)
total_do_produto = produto.calcular_total()

print(f"O total {nome_produto} é: R${total_do_produto:.2f}")
