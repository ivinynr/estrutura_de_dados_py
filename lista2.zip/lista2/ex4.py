class ContaBancaria:
    def __init__(self, titular, saldo=0):
        self.titular = titular
        self.saldo = saldo
    
    def depositar(self, valor):
        if valor > 0:
            self.saldo += valor
            return f"Depósito de R${valor} realizado com sucesso. Novo saldo: R${self.saldo}"
        else:
            return "Valor do depósito deve ser maior que zero."
    
    def sacar(self, valor):
        if 0 < valor <= self.saldo:
            self.saldo -= valor
            return f"Saque de R${valor} realizado com sucesso. Novo saldo: R${self.saldo}"
        elif valor > self.saldo:
            return "Saldo insuficiente para realizar o saque."
        else:
            return "Valor do saque deve ser maior que zero."


titular_conta = input("Digite o nome do titular da conta: ")
conta = ContaBancaria(titular_conta)

print(conta.depositar(100))
print(conta.sacar(50))       
print(conta.sacar(70))       
