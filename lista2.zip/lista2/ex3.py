class Retangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura
    
    def calcular_area(self):
        area = self.base * self.altura
        return area

base_retangulo = float(input("Digite a base do retângulo: "))
altura_retangulo = float(input("Digite a altura do retângulo: "))

retangulo = Retangulo(base_retangulo, altura_retangulo)
area_do_retangulo = retangulo.calcular_area()

print(f"A área do retângulo com base {base_retangulo} e altura {altura_retangulo} é: {area_do_retangulo}")
