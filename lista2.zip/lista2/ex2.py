class Livro:
    def __init__(self, titulo, autor):
        self.titulo = titulo
        self.autor = autor
    
    def detalhes(self):
        return f"Título: {self.titulo}\nAutor: {self.autor}"


titulo = input("Digite o título do livro: ")
autor = input("Digite o nome do autor do livro: ")

livro = Livro(titulo, autor)
informacoes_do_livro = livro.detalhes()

print("\nDetalhes do Livro:")
print(informacoes_do_livro)
