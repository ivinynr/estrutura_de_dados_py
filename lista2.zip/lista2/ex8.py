class Aluno:
    def __init__(self, nome, notas):
        self.nome = nome
        self.notas = notas
    
    def calcular_media(self):
        if len(self.notas) > 0:
            media = sum(self.notas) / len(self.notas)
            return media
        else:
            return "O aluno não possui notas."

nome_aluno = input("Digite o nome do aluno: ")
notas_aluno = input("Digite as notas do aluno separadas por espaço: ").split()
notas_aluno = [float(nota) for nota in notas_aluno]  

aluno = Aluno(nome_aluno, notas_aluno)
media_do_aluno = aluno.calcular_media()

if type(media_do_aluno) == str:
    print(media_do_aluno)
else:
    print(f"A média das notas do aluno {nome_aluno} é: {media_do_aluno:.2f}")
