class Funcionario:
    def __init__(self, nome, salario, cargo):
        self.nome = nome
        self.salario = salario
        self.cargo = cargo
    
    def aumentar_salario(self, percentual_aumento):
        aumento = (self.salario * percentual_aumento) / 100
        self.salario += aumento
        return f"O salário de {self.nome} foi aumentado em R${aumento:.2f}. Novo salário: R${self.salario:.2f}"
nome_funcionario = input("Digite o nome do funcionário: ")
salario_funcionario = float(input("Digite o salário do funcionário: "))
cargo_funcionario = input("Digite o cargo do funcionário: ")

funcionario = Funcionario(nome_funcionario, salario_funcionario, cargo_funcionario)
percentual_aumento = float(input("Digite o percentual de aumento do salário: "))

mensagem = funcionario.aumentar_salario(percentual_aumento)
print(mensagem)
