#Escreva um programa que solicite um número ao usuário e imprima todos os números pares de 0 até esse numero

numero=int(input("digite um numero: "))

for i in range(0, numero + 1,2):
    print (i)
    
    print("numeros pares: ")