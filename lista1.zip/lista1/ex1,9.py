#Escreva um programa que leia uma lista de nomes e retorne uma nova lista com apenas os nomes que começam com a letra 'A'.

lista=input("insira lista de nomes: ")
nomes=lista.split()
nomes_com_a = [nome for nome in nomes if nome.startswith('A') or nome.startswith('a')]

if nomes_com_a:
    print("Nomes que começam com 'a':", nomes_com_a)
else:
    print("Não tem nomes que começam com 'a' na lista.")




