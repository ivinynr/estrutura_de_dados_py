#Faça um programa que calcule a média de três números inseridos pelo usuário

n1=float(input("digite o primeiro numero: "))
n2=float(input("digite o segundo numero: "))
n3=float(input("digite o terceiro numero: "))

media=(n1+ n2+ n3) /3
print(f'A media dos numeros {n1}, {n2}, {n3} é: {media}')