#Faça um programa que leia uma lista de números e retorne a média dos números pares.

lista = input("Insira uma lista de números: ")
numeros = [float(numero) for numero in lista.split()]
numeros_pares = [numero for numero in numeros if numero % 2 == 0]


if numeros_pares:
    media_pares = sum(numeros_pares) / len(numeros_pares)
    print(f"A média dos números pares: {media_pares}")
else:
    print("Não tem numeros pares")
